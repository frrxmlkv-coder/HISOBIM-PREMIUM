HISOBIM PREMIUM — Android manba loyihasi

Qo‘shilgan va mavjud imkoniyatlar:
- Kirim va chiqim kiritish, balansni yangilash
- O‘tkazma kiritish (balansdan yechiladi)
- Kreditlar ro‘yxati, yangi kredit va kredit to‘lovi
- Operatsiyalar tarixi (sana, tur, izoh, summa)
- Hisobot: jami va joriy oy kirim/chiqim, sof natija, balans
- Ma’lumotlarni SharedPreferences orqali qurilmada saqlash

Yig‘ish:
1. Loyihani Android Studio’da oching.
2. Gradle Sync tugashini kuting.
3. Build > Build Bundle(s) / APK(s) > Build APK(s) ni tanlang.
4. APK app/build/outputs/apk/debug/app-debug.apk ichida hosil bo‘ladi.

Talablar: Android Studio, JDK 17, Android SDK 35, Android Gradle Plugin 8.7.3.

Eslatma: bu manba loyihasi. Ushbu muhitda Android SDK/Gradle yig‘ish vositalari mavjud bo‘lmagani sababli APK bu ZIP ichida build qilingan deb da’vo qilinmaydi. Real moliyaviy ma’lumotlarni kiritishdan oldin qurilmada test qiling va zaxira nusxa saqlang.
